package com.hton.dao.filters;

public enum  SearchCondition {
    EQUALS, LIKE, NOT_LIKE, NOT_EQUALS, GREATER_THAN, LESS_THAN, GREATER_OR_EQUAL_THAN, LESS_OR_EQUAL_THAN, NULL, NOT_NULL, MAX, MIN
}

package com.hton.entities;

public enum Role {
    ADMIN,
    USER
}

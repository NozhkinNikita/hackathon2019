package com.hton.dao.filters;

public enum Operation {
    AND, OR
}

package com.hton.dao.filters;

public enum SortDirection {
    ASC, DESC
}

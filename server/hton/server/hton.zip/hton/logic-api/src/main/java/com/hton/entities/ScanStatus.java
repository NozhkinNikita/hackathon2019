package com.hton.entities;

public enum ScanStatus {

    DRAFT,
    FINISHED
}
